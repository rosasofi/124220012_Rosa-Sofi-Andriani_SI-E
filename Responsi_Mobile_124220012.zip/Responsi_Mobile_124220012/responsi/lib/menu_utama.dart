import 'package:flutter/material.dart';
import 'package:responsi/restaurant_list.dart';

class MenuUtama extends StatefulWidget {
  const MenuUtama({Key? key}) : super(key: key);

  @override
  State<MenuUtama> createState() => _MenuUtama();
}

class _MenuUtama extends State<MenuUtama> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Center(
            child: Column(
              children: [
                Text('Restaurant'),
              ],
            ),
          ),
        ),
        body: GridView.count(
          padding: const EdgeInsets.all(25),
          crossAxisCount: 2, // Keep 2 items per row (adjust if needed)
          crossAxisSpacing: 30, // Add space between columns
          mainAxisSpacing: 15, // Add space between rows
          children: <Widget>[
            Card(
              margin: const EdgeInsets.all(8),
              child: InkWell(
                onTap: () {},
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.all(0),
                    backgroundColor:
                        Colors.white, // Make button background white
                    shadowColor: Colors.transparent, // Remove shadow
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Image.asset(
                        'assets/images/melting.jpg',
                        width: 200, // Increased width for rectangular shape
                        height: 120, // Reduced height to make it rectangular
                        fit: BoxFit.cover,
                      ),
                      Text(
                        "Melting Pot",
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Card(
              margin: const EdgeInsets.all(8),
              child: InkWell(
                onTap: () {},
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.all(0),
                    backgroundColor: Colors.white,
                    shadowColor: Colors.transparent,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Image.asset(
                        'assets/image/restaurant.png',
                        width: 200, // Increased width for rectangular shape
                        height: 120, // Reduced height to make it rectangular
                        fit: BoxFit.cover,
                      ),
                      Text("Kafe Kita",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                ),
              ),
            ),
            Card(
              margin: const EdgeInsets.all(8),
              child: InkWell(
                onTap: () {},
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RestaurantList()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.all(0),
                    backgroundColor: Colors.white,
                    shadowColor: Colors.transparent,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const <Widget>[
                      Image(
                        image: AssetImage(
                            'https://restaurant-api.dicoding.dev/images/small/<pictureId>'),
                        width: 200, // Increased width for rectangular shape
                        height: 120, // Reduced height to make it rectangular
                        fit: BoxFit.cover,
                      ),
                      Text("Kafe",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  RestaurantList() {}

  Widget _buildUserReviews() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "User Reviews",
          style: TextStyle(
            fontFamily: 'Montserrat',
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 10),
        // Review 1
        _buildReview(
          "John Doe",
          "Great Restaurant! Love the atmosphere.",
          5,
        ),
        const SizedBox(height: 10),
        // Review 2
        _buildReview(
          "Jane Smith",
          "The pastries are fantastic. Will visit again!",
          4,
        ),
        const SizedBox(height: 10),
        // Review 3
        _buildReview(
          "Alice Johnson",
          "Good service, but the coffee could be hotter.",
          3,
        ),
      ],
    );
  }

  Widget _buildReview(String name, String reviewText, int rating) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile image placeholder (could be replaced with actual image)
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.brown[200],
              child: Text(
                name[0], // Show the first letter of the name
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(width: 10),
            // Review details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    reviewText,
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 14,
                      color: Colors.brown[600],
                    ),
                  ),
                  const SizedBox(height: 5),
                  // Rating (Stars)
                  Row(
                    children: List.generate(
                      5,
                      (index) => Icon(
                        index < rating ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
