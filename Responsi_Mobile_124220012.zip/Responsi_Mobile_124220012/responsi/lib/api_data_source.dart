import 'package:responsi/base_network.dart';

class ApiDataSource {
  static ApiDataSource instance = ApiDataSource();

  Future<Map<String, dynamic>> loadListRestaurant() {
    return BaseNetwork.get("https://restaurant-api.dicoding.dev/list");
  }

  Future<Map<String, dynamic>> loadDetailRestaurant(int newsId) {
    return BaseNetwork.get(
        "https://restaurant-api.dicoding.dev/detail/rqdv5juczeskfw1e867");
  }

  Future<Map<String, dynamic>> loadBlogs() {
    return BaseNetwork.get("blogs/?format=json");
  }

  Future<Map<String, dynamic>> loadDetailBlogs(int blogId) {
    return BaseNetwork.get("blogs/?format=json/$blogId");
  }

  Future<Map<String, dynamic>> loadReports() {
    return BaseNetwork.get("reports/?format=json");
  }

  Future<Map<String, dynamic>> loadDetailReports(int reportsId) {
    return BaseNetwork.get("reports/?format=json/$reportsId");
  }
}
