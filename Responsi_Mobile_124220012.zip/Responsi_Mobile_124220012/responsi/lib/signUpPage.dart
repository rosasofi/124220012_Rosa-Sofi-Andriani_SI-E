import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:responsi/dataModel.dart';
import 'package:responsi/hiveDatabase.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  final HiveDatabase _hive = HiveDatabase();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Register Your Account",
          style: TextStyle(
            fontFamily: "Montserrat",
            color: Color.fromARGB(255, 0, 0, 0), // Red title color
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back_ios,
            color: const Color.fromARGB(255, 0, 0, 0), // Red back icon
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        color: Colors.grey[200], // Light gray background
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextFormField(
              controller: _usernameController,
              decoration: const InputDecoration(
                hintText: "Username",
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat',
                  color: Colors.grey, // Gray hint text
                ),
                contentPadding: EdgeInsets.all(8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(
                    color: Colors.grey, // Gray border
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(
                        255, 78, 97, 190), // Red focused border
                  ),
                ),
              ),
              validator: (String? value) {
                if (value!.trim().isEmpty) {
                  return 'Username is required';
                }
              },
            ),
            Padding(padding: const EdgeInsets.only(bottom: 10)),
            TextFormField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                hintText: "Password",
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat',
                  color: Colors.grey, // Gray hint text
                ),
                contentPadding: EdgeInsets.all(8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(
                    color: Colors.grey, // Gray border
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(
                        255, 78, 97, 190), // Red focused border
                  ),
                ),
              ),
              validator: (String? value) {
                if (value!.trim().isEmpty) {
                  return 'Password is required';
                }
              },
            ),
            Padding(padding: const EdgeInsets.only(bottom: 25)),
            _buildRegisterButton(),
          ],
        ),
      ),
    );
  }

  Widget _commonSubmitButton({
    required String labelButton,
    required Function(String) submitCallback,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              const Color.fromARGB(255, 78, 97, 190), // Red button color
          padding: EdgeInsets.all(10.0),
          fixedSize: Size(180, 40),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15), // <-- Radius
          ),
        ),
        child: Text(
          labelButton,
          style: TextStyle(
            fontFamily: 'Montserrat',
            fontWeight: FontWeight.w600,
            fontSize: 14,
            color: Colors.white, // White text color
          ),
        ),
        onPressed: () {
          submitCallback(labelButton);
        },
      ),
    );
  }

  Widget _buildRegisterButton() {
    return _commonSubmitButton(
      labelButton: "Sign Up",
      submitCallback: (value) {
        if (_usernameController.text.isNotEmpty &&
            _passwordController.text.isNotEmpty) {
          var encryptedPassword =
              DataModel.encryptPassword(_passwordController.text);

          print('Username: ${_usernameController.text}');
          print('Password: ${_passwordController.text}');
          print('Encrypted Password: $encryptedPassword');

          _hive.addData(
            DataModel(
              username: _usernameController.text,
              password: _passwordController.text,
              encryptedPassword: encryptedPassword,
            ),
          );

          _usernameController.clear();
          _passwordController.clear();

          setState(() {});

          Navigator.pop(context);
        }
      },
    );
  }
}
